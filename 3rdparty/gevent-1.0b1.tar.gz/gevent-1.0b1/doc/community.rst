Community
=========

The official mailing list is hosted on `Google Groups (gevent)`_. To subscribe via email, send a message to gevent+subscribe@googlegroups.com

You're also welcome to join `#gevent`_ IRC channel on freenode.


Russian group
-------------

Русскоязычная группа находится здесь: `Google Groups (gevent-ru)`_. Чтобы подписаться, отправьте сообщение на gevent-ru+subscribe@googlegroups.com


.. _Google Groups (gevent): http://groups.google.com/group/gevent
.. _#gevent: http://webchat.freenode.net/?channels=gevent
.. _Google Groups (gevent-ru): http://groups.google.com/group/gevent-ru
