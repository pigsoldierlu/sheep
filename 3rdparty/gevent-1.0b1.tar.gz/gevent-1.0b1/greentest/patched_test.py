import helper
exec helper.prepare_stdlib_test(__file__) in globals()
