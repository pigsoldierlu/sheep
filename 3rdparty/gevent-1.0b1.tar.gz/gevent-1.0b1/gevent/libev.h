#if defined(LIBEV_EMBED)
#include "ev.c"
#else
#include "ev.h"
#endif
